<?php get_header(); ?>

<main class="main-wrapper">
    <!-- Hero Section -->
    <section class="section_home">
        <div class="hero_wrap">
            <div>
                <div class="hero_layout">
                    <div animation="badge" class="badge" style="width:2.5rem;height:2rem">
                        <img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690a4d4e32a51cfdc18da770_star.svg" loading="lazy" alt="" class="badge_image"/>
                        <div class="badge_text">From Strategy to Success</div>
                    </div>
                    <div class="max-heading is-42rem">
                        <h1 animation="heading">Build and <em animation="growth">Growth</em> with Scalable Tools</h1>
                    </div>
                    <div class="max-description is-32rem">
                        <div animation="description">Easily adapt to changes and scale your operations with our flexible infrastructure, designed to support your business growth.</div>
                    </div>
                </div>
                <div class="spacer-xhuge"></div>
                <div animation="buttons" class="hero_button-wrap">
                    <a animation="" data-wf--button--variant="base" href="#" class="button_component w-inline-block">
                        <div class="button_content">
                            <div class="button_text is-one">Get Started</div>
                            <div class="button_text is-two">Get Started</div>
                        </div>
                    </a>
                    <a animation="" data-wf--button--variant="secondary" href="#" class="button_component w-variant-02578fa3-4dfb-f9fd-9090-5ef572c52b8e w-inline-block">
                        <div class="button_content">
                            <div class="button_text is-one">Learn More</div>
                            <div class="button_text is-two">Learn More</div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="hero_visuals">
                <div animation="card" class="hero_card-img is-one"><img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690a5dd74a96e95e029c108c_6ae34b015bd10b43dfb1eac6348006ee_hero-card-01.svg" loading="lazy" alt="" class="img"/></div>
                <div animation="card" class="hero_card-img is-two"><img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690a5dd73672e3f40248304f_7dded8d5fb4e0438e18f765cd3dd452e_hero-card-02.svg" loading="lazy" alt="" class="img"/></div>
                <div animation="card" class="hero_card-img is-three"><img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690a5dd62873004cf5e10e31_ddf94abfbe8e944efabeb353a537c801_hero-card-03.svg" loading="lazy" alt="" class="img"/></div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section class="section_about">
        <div class="padding-section-large"></div>
        <div class="padding-global">
            <div class="container-large">
                <div>
                    <div class="badge-wrapper">
                        <div animation="" data-wf--badge--variant="secondary" class="badge w-variant-bbfb6a6c-d3ec-5a08-a531-cec36f932128">
                            <img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690a76826336a11ac7b3c5cf_star-blue.svg" loading="lazy" alt="" class="badge_image"/>
                            <div class="badge_text">about us</div>
                        </div>
                    </div>
                    <div class="spacer-xlarge"></div>
                    <h2 animation="large-heading" class="heading-large">We are passionate about empowering individuals and businesses to take control of their finances and achieve their financial goals.</h2>
                </div>
                <div class="spacer"><div STYLE="height:4rem" class="spacer-desktop"></div></div>
                <div class="about_image">
                    <img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690a7785cc2e417de28d89e1_90b146ec1080897a348935ba2aeba926_about-img.avif" loading="lazy" alt="" class="img"/>
                    <div class="about_image-card is-right"><img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690e1f2ec247d60ed665340a_5f444e6f184fb73b88ff27d4b517466e_about-img-right.svg" loading="lazy" alt="" class="img"/></div>
                    <div class="about_image-card is-left"><img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690e1a7cad5fac0520b7ea84_d0816e4bc39facf14f3bd8cdf5b2bacf_about-img-left.svg" loading="lazy" alt="" class="img"/></div>
                </div>
                <div class="spacer"><div STYLE="height:4rem" class="spacer-desktop"></div></div>
                <div class="grow-container">
                    <div class="about_stats-grid">
                        <div class="about_stat grow-element"><div class="stat-display">80%</div><div>Reduction in reporting time.</div></div>
                        <div class="about_stat grow-element"><div class="stat-display">$70k</div><div>Savings per month (approx)</div></div>
                        <div class="about_stat grow-element"><div class="stat-display">99</div><div>Increase in billing hours</div></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="padding-section-large"></div>
    </section>

    <!-- Benefits Section -->
    <section class="section_benefits">
        <div class="padding-box">
            <div class="benefits_wrap">
                <div class="padding-section-medium"></div>
                <div class="container-xlarge">
                    <div>
                        <div class="badge-wrapper">
                            <div animation="" data-wf--badge--variant="base" class="badge">
                                <img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690a76826336a11ac7b3c5cf_star-blue.svg" loading="lazy" alt="" class="badge_image"/>
                                <div class="badge_text">Benefits</div>
                            </div>
                        </div>
                        <div class="spacer-xlarge"></div>
                        <div class="max-description is-45rem align-center">
                            <h2 animation="large-heading" class="text-color-on-primary text-align-center">Make payment easy, simplify your finance</h2>
                        </div>
                        <div class="spacer-xlarge"></div>
                        <div class="max-description is-33rem align-center">
                            <div class="text-color-on-primary text-align-center">Easily adapt to changes and scale your operations with our flexible infrastructure, designed to support your business growth.</div>
                        </div>
                    </div>
                    <div class="benefits_grid grow-container">
                        <div class="grow-element mobile-width">
                            <div class="benefits_card">
                                <img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690a7f48b8545339787a6c61_benefits-icon.svg" loading="lazy" alt="" class="card_icon"/>
                                <div><div class="font-header text-2xl">Budgeting and expense tracking</div><div class="spacer-xsmall"></div><div class="text-color-secondary">Take control of your finances with our intuitive budgeting and expense-tracking solution. Easily manage your income</div></div>
                            </div>
                        </div>
                        <div class="grow-element mobile-width">
                            <div class="benefits_card">
                                <img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690a847f93af97740832faac_benefits-icon02.svg" loading="lazy" alt="" class="card_icon"/>
                                <div><div class="font-header text-2xl">Investment management</div><div class="spacer-xsmall"></div><div class="text-color-secondary">Take control of your finances with our intuitive budgeting and expense-tracking solution. Easily manage your income</div></div>
                            </div>
                        </div>
                        <div class="grow-element mobile-width">
                            <div class="benefits_card">
                                <img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690a847f6f038d160a332f30_benefits-icon03.svg" loading="lazy" alt="" class="card_icon"/>
                                <div><div class="font-header text-2xl">The digital transformation journey</div><div class="spacer-xsmall"></div><div class="text-color-secondary">involves integrating digital technologies into all areas of a business, fundamentally changing how it operates</div></div>
                            </div>
                        </div>
                        <div class="grow-element mobile-width">
                            <div class="benefits_card">
                                <img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690a847f8ac4e4c5b8f157e9_benefits-icon04.svg" loading="lazy" alt="" class="card_icon"/>
                                <div><div class="font-header text-2xl">Market expansion strategy </div><div class="spacer-xsmall"></div><div class="text-color-secondary">A market expansion strategy involves identifying and entering new markets to increase a company's customer base and revenue</div></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="padding-section-medium"></div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="section_features">
        <div class="padding-section-large"></div>
        <div class="padding-global">
            <div class="container-medium">
                <div>
                    <div class="badge-wrapper">
                        <div animation="" data-wf--badge--variant="secondary" class="badge w-variant-bbfb6a6c-d3ec-5a08-a531-cec36f932128">
                            <img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690a76826336a11ac7b3c5cf_star-blue.svg" loading="lazy" alt="" class="badge_image"/><div class="badge_text">Features</div>
                        </div>
                    </div>
                    <div class="spacer-xlarge"></div>
                    <div class="max-description is-49rem align-center">
                        <h2 animation="large-heading" class="text-align-center">Empowering and <em>strengthening</em> your financial success</h2>
                    </div>
                    <div class="spacer-xlarge"></div>
                    <div class="max-description is-33rem align-center">
                        <div class="text-color-secondary text-align-center">Our platform provides advanced tools and insights to help you manage, grow, and secure your financial assets.</div>
                    </div>
                    <div class="spacer-xlarge"></div>
                    <div class="button-wrapper is-center">
                        <a animation="" data-wf--button--variant="base" href="#" class="button_component w-inline-block">
                            <div class="button_content"><div class="button_text is-one">Learn More</div><div class="button_text is-two">Learn More</div></div>
                        </a>
                    </div>
                    <div class="spacer"><div STYLE="height:4rem" class="spacer-desktop"></div></div>
                </div>
                <div class="features_grid grow-container">
                    <div class="grow-element full-height">
                        <div class="feature_card">
                            <div class="features_card-title"><div class="card_badge"><div class="text-xs">Clean interface</div></div><h3 class="text-4xl">Intuitive user interface</h3></div>
                            <div class="feature_image"><img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690a8c91f499e5c9b2585c6b_features-img01.svg" loading="lazy" alt="" class="img"/><div class="bottom_gradient"></div></div>
                            <div class="text-color-secondary">User-friendly design for effortless navigation and usability</div>
                        </div>
                    </div>
                    <div class="grow-element">
                        <div class="feature_card">
                            <div class="features_card-title"><div class="card_badge"><div class="text-xs">Faster</div></div><h3 class="text-4xl">Automated processes </h3></div>
                            <div class="feature_image"><img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690a8fa81b4858ce7295ae6a_features-img02.svg" loading="lazy" alt="" class="img"/><div class="bottom_gradient"></div></div>
                            <div class="text-color-secondary">Streamlined workflows to increase efficiency and reduce manual tasks</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="padding-section-large"></div>
    </section>

    <!-- Core Features Section -->
    <section class="section_core">
        <div class="padding-section-large"></div>
        <div class="padding-global">
            <div class="container-medium">
                <div class="badge-wrapper">
                    <div animation="" data-wf--badge--variant="secondary" class="badge w-variant-bbfb6a6c-d3ec-5a08-a531-cec36f932128">
                        <img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690a76826336a11ac7b3c5cf_star-blue.svg" loading="lazy" alt="" class="badge_image"/><div class="badge_text">Core features</div>
                    </div>
                </div>
                <div class="spacer-xlarge"></div>
                <div class="max-description is-45rem align-center">
                    <h2 animation="large-heading" class="text-align-center">Core features that set us apart from the <em>competition</em></h2>
                </div>
                <div class="spacer-xlarge"></div>
                <div class="max-description is-38rem align-center">
                    <div class="text-color-secondary text-align-center">Explore our standout features designed to deliver exceptional performance and value.</div>
                </div>
                <div class="spacer"><div STYLE="height:4rem" class="spacer-desktop"></div></div>
                <div class="core_grid grow-container">
                    <div class="grow-element mobile-width">
                        <div class="core_card">
                            <img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690ba277509957a6b914585b_core-icon01.svg" loading="lazy" alt="" class="card_icon"/>
                            <div><div class="text-2xl font-header">Real-time analytics</div><div class="spacer-xsmall"></div><div>Gain actionable insights with our real-time analytics feature</div></div>
                            <a href="#" class="button_component w-inline-block"><div class="button_content"><div class="button_text">Learn More</div></div></a>
                        </div>
                    </div>
                    <div class="grow-element mobile-width">
                        <div class="core_card">
                            <img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690ba27708f414a73f5ae566_core-icon02.svg" loading="lazy" alt="" class="card_icon"/>
                            <div><div class="text-2xl font-header">Mobile accessibility</div><div class="spacer-xsmall"></div><div>Manage your finances on the go with our mobile-friendly platform</div></div>
                            <a href="#" class="button_component w-inline-block"><div class="button_content"><div class="button_text">Learn More</div></div></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="padding-section-large"></div>
    </section>

    <!-- Testimonials Section -->
    <section class="section_testimonials">
        <div class="padding-section-large"></div>
        <div class="padding-global">
            <div class="container-medium">
                <div class="badge-wrapper">
                    <div animation="" data-wf--badge--variant="secondary" class="badge w-variant-bbfb6a6c-d3ec-5a08-a531-cec36f932128">
                        <img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690a76826336a11ac7b3c5cf_star-blue.svg" loading="lazy" alt="" class="badge_image"/><div class="badge_text">Testimonials</div>
                    </div>
                </div>
                <div class="spacer-xlarge"></div>
                <div class="max-description is-45rem align-center">
                    <h2 animation="large-heading" class="text-align-center">What our <em>clients</em> are saying</h2>
                </div>
            </div>
        </div>
        <div class="loop_wrap">
            <div class="testimonial_loop">
                <div class="testimonial_card">
                    <img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690bdc0f2ee4b12eb394e7fd_testimonial-01.avif" loading="lazy" alt="" class="testimonial_img"/>
                    <img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690bd6b1164b5b4f73b38197_quote-icon.svg" loading="lazy" alt="" class="icon-1x1-xlarge"/>
                    <div class="text-color-secondary">Catalis has completely transformed the way I manage my finances. Highly recommend it!</div>
                    <div><div class="text-weight-medium">Jaxson Baptista</div><div class="text-color-secondary">Manager at Lunoxinc</div></div>
                    <div class="testimonial_sign">Jaxson Baptista</div>
                </div>
                <!-- More Testimonials -->
            </div>
        </div>
        <div class="padding-section-large"></div>
    </section>

    <!-- Blogs Section -->
    <section class="section_blogs">
        <div class="padding-section-large"></div>
        <div class="padding-global">
            <div class="container-medium">
                <div class="badge-wrapper">
                    <div animation="" data-wf--badge--variant="secondary" class="badge w-variant-bbfb6a6c-d3ec-5a08-a531-cec36f932128">
                        <img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690a76826336a11ac7b3c5cf_star-blue.svg" loading="lazy" alt="" class="badge_image"/><div class="badge_text">Blog and articles</div>
                    </div>
                </div>
                <div class="spacer-xlarge"></div>
                <div class="max-description is-45rem align-center">
                    <h2 animation="large-heading" class="text-align-center">Discover the latest <em>blogs</em></h2>
                </div>
                <div class="spacer-xlarge"></div>
                <div class="blog_grid grow-container">
                    <div class="blog_card grow-element">
                        <a href="#" class="blog_card-content w-inline-block">
                            <div class="blog_card-img"><img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08c/690d0125b2a59758200e5245_blog-card-01.webp" loading="lazy" alt="" class="img"/></div>
                            <div class="blog_info">
                                <h3 class="text-xl text-style-2lines">The Ultimate Guide to Budgeting in 2024</h3>
                                <div class="text-color-secondary text-style-3lines">Software as a Service (SaaS) has revolutionized how businesses operate.</div>
                            </div>
                        </a>
                        <a href="#" class="button_component w-inline-block"><div class="button_content"><div class="button_text">Read more</div></div></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="padding-section-large"></div>
    </section>

    <!-- Join Us Section -->
    <section class="section_join">
        <div class="padding-box">
            <div class="join_wrap">
                <div class="container-medium">
                    <div class="badge-wrapper">
                        <div animation="" data-wf--badge--variant="secondary" class="badge w-variant-bbfb6a6c-d3ec-5a08-a531-cec36f932128">
                            <img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690a76826336a11ac7b3c5cf_star-blue.svg" loading="lazy" alt="" class="badge_image"/><div class="badge_text">Join Us</div>
                        </div>
                    </div>
                    <div class="spacer-xlarge"></div>
                    <div class="max-description is-45rem align-center">
                        <h2 animation="large-heading" class="text-color-on-primary text-align-center">Achieve operational excellence with <em>Catalis</em></h2>
                    </div>
                    <div class="spacer-xlarge"></div>
                    <div class="button-wrapper is-center">
                        <a href="#" class="button_component w-inline-block"><div class="button_content"><div class="button_text">Get Started</div></div></a>
                    </div>
                </div>
                <div class="join_img is-left"><img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690ce435b295f16c937cbef7_b37d532fd83b00c1e636745a11a55287_join-left.svg" loading="lazy" alt="" class="img"/></div>
                <div class="join_img is-right"><img src="https://cdn.prod.website-files.com/690a3d4b70be67fbdfcdc08a/690ce435bd41a8da12a0be42_459daa8b4411ff62fef7ad254a9456d5_join-right.svg" loading="lazy" alt="" class="img"/></div>
            </div>
        </div>
    </section>

    <!-- Pricing Section -->
    <section class="section_pricing">
        <div class="padding-box">
            <div class="pricing_wrap">
                <div class="padding-section-large"></div>
                <div class="container-medium">
                    <h2 animation="large-heading" class="text-color-on-primary text-align-center">Simple, transparent <em>pricing</em></h2>
                    <div class="spacer-xlarge"></div>
                    <div class="pricing_grid grow-container">
                        <div class="grow-element mobile-width">
                            <div class="pricing_card">
                                <h3 class="text-2xl">Starter Plan</h3>
                                <div class="pricing_card-price"><div class="h6">$50.00</div><div class="price-text">/month</div></div>
                                <div class="margin-top-auto">
                                    <a href="#" class="button_component w-inline-block"><div class="button_content"><div class="button_text">Get Started</div></div></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>
